<?php $__env->startSection('content'); ?>
    <h1>ساخت دسته ها</h1>
    <?php echo Form::open(['action' => 'CategoryController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <div class="form-group">
        <?php echo e(Form::label('name', 'name')); ?>

        <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'name'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(Form::label('slug', 'slug')); ?>

        <?php echo e(Form::text('slug', '', ['class' => 'form-control', 'placeholder' => 'slug'])); ?>

    </div>

    <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>





    
        
    
    
        
        
            
                
                    
                
            

        

        
            
                
                
            
        
        


        
            
                
            
        
    




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>