



<nav class="navbar navbar-expand-lg navbar-light bg-dark ">
        
                
        
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ">
              <li class="nav-item">
              <a class="navbar-brand" href="<?php echo e(url('/')); ?>"> 
                            <img src="<?php echo e(url('/image/logo.png')); ?>" alt="" style="width:80%"> 
                        </a>
              </li>
              
            <li class="nav-item  ">
              <a class="nav-link nav-link-text" href="/">خانه<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
            <a class="nav-link nav-link-text" href="<?php echo e(url('about')); ?>">درباره ما </a>
            </li>
            <li class="nav-item">
                <a class="nav-link nav-link-text" href="<?php echo e(url('posts')); ?>">درخواست‌ها</a>
              </li>

            <?php if(Auth::guest()): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle nav-link-text" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                ورود/ثبت‌نام
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                
                <a class="dropdown-item" style="text-align:right" href="/login">ورود</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" style="text-align:right" href="/register">ثبت نام</a>
              </div>
            </li>
            <?php else: ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle nav-link-text" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  ناحیه کاربری
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  
                  <a class="dropdown-item" style="text-align:right" href="/dashboard">پروفایل کاربری</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" style="text-align:right" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                      document.getElementById('logout-form').submit();">
                            خروج
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                </div>
              </li>
        <?php endif; ?>
            
            
        
          </ul>
          <form class="form-inline my-2 my-lg-0 mr-auto" action="/search" method="get">
            <input class="form-control mr-sm-2 form-control-search  " type="text" name="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">جست‌وجو</button>
          </form>
        </div>
          <a class="navbar-brand logo-mobile" href="<?php echo e(url('/')); ?>"> 
            <img src="<?php echo e(url('/image/logo.png')); ?>" alt="" style="width:80%"> 
        </a>


        
      </nav>