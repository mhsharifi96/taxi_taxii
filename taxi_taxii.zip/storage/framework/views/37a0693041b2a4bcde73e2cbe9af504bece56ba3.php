<?php $__env->startSection('content'); ?>


<div class="container">
    
    
    
    
    
    
    <div class="row justify-content-center">
    <div class="col-md-6">
    <div class="card margin-card">
    <header class="card-header">
        
        <h4 class="card-title mt-2">ثبت نام در اولین تاکسی ذهنی در ایران</h4>
    </header>
    <article class="card-body">
    <form role="form" method="post" action="<?php echo e(route('register')); ?>">
        <div class="form-row" >
            <?php echo e(csrf_field()); ?>


            <div class="col form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <label for="name">نام</label>   
                  
                  <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus placeholder="نام">
                  <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
            </div> <!-- form-group end.// -->

            <div class="col form-group">
                <label>نام خانوادگی</label>
                  <input type="text" class="form-control" placeholder="فامیلتون">
            </div> <!-- form-group end.// -->
        </div> <!-- form-row end.// -->

        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                
            <label>ایمیل</label>
            
            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required placeholder="ایمیل">
            <small class="form-text text-muted">اسپم نمیکنیم :)</small>
            <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
        </div> <!-- form-group end.// -->
        
        
        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                
            <label for="password" class="">رمز عبور</label>
            
            <input id="password" type="password" class="form-control" name="password" required placeholder="رمزعبور">
            <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
        </div> <!-- form-group end.// -->  
        <div class="form-group">
            <label for="password-confirm" class="">تکرار پسورد</label>
            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="تایید پسورد">
        </div> 
        <div class="form-group">
            <button type="submit" class="btn btn-primary btn-block"> ثبت نام </button>
            
            
        </div> <!-- form-group// -->      
        <small class="text-muted">By clicking the 'Sign Up' button, you confirm that you accept our <br> Terms of use and Privacy Policy.</small>                                          
    </form>
    </article> <!-- card-body end .// -->
    <div class="border-top card-body text-center">اکانت دارید؟ <a href="/login">Log In</a></div>
    </div> <!-- card.// -->
    </div> <!-- col.//-->
    
    </div> <!-- row.//-->
    
    
    </div> 
    <!--container end.//-->
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>