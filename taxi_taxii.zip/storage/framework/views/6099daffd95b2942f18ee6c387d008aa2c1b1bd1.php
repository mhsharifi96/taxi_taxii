<?php $__env->startSection('content'); ?>
<div class="container create-class">
    <h1>درخواست تاکسی ذهنی</h1>
    <?php echo Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <div class="row">
            <div class="col-md-6 col-12">
                    <div class="form-group">
                        <?php echo e(Form::label('title', 'موضوع')); ?>

                        
                        <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'مقصد'])); ?>

                    </div>
                </div>
                <div class="col-md-6 col-12" style="order:2">
                        <div class="form-group">
                            <?php echo e(Form::label('tag', 'تگ ها')); ?>

                            <?php echo e(Form::text('tag', '', ['class' => 'form-control','id' =>'form-tags-3', 'placeholder' => 'تگ'])); ?>

                           <small style="color: red;">بعد از وارد کردن هر تگ enter را بزنید.</small>
                        </div>
                    
                    </div>
    </div>
    <div class="row">
            <div class="col-md-6 col-12">
                    <div class="form-group">
                        <div class="col-sm-12">
                            <lable for="category_id" class="control-label bold-class">دسته بندی</lable>
                            <select class="form-control" name="category_id" id="category_id">
                                <?php $__currentLoopData = \App\Category::latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" > <?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>

        <div class="col-md-6 col-12" style="order:2">
            <div class="form-group">
                <?php echo e(Form::label('account', 'آيدی/ایمیل')); ?>

                <?php echo e(Form::text('account', '', ['class' => 'form-control','id' =>'form-tags-3', 'placeholder' => 'آیدی فضای مجازی'])); ?>

            </div>


    </div>
            
                
                    
        
                    
                        
        
                        
                    
                
                    
                

    
    
        
    </div>

        
        <div class="form-group">
            <?php echo e(Form::label('body', 'توضیحات')); ?>

            <?php echo e(Form::textarea('body', '', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'تاکسی تاکسی اولین تاکسی ذهنی در ایران'])); ?>

        </div>
        
        <div>
                <?php echo e(Form::submit('ارسال', ['class'=>'btn btn-primary'])); ?>

        </div>

    <?php echo Form::close(); ?>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>