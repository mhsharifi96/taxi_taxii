<?php $__env->startComponent('mail::message'); ?>
##ایمیل فعال سازی sfas

[لینک فعال سازی](<?php echo e(route('activation.account',$code)); ?>) - The web framework used
     

<?php echo $__env->renderComponent(); ?>


