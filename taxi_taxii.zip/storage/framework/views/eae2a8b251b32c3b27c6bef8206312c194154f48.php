<?php $__env->startSection('content'); ?>
    <div class="contain">
        <h1>Posts</h1>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <?php if(count($post) > 0): ?>

            
            <div class="container">

                <div class="row">

                        <div class="col-sm-6 col-md-4 col-lg-3 mt-4 mb-4 d-flex">
                            <div class="card flex-fill shadow">
                                <img class="card-img-top" src="https://picsum.photos/200/150/?random">
                                <div class="card-block">
                                    <a href="/posts/<?php echo e($post->id); ?>">
                                        <h4 class="card-title"><?php echo e($post->title); ?></h4>
                                    </a>

                                    <div class="meta">
                                        <a href="#"><?php echo e($post->category->name); ?></a>
                                    </div>
                                    <div class="card-text">
                                        <h3 style="    margin-bottom: 4rem;                                        ">
                                            <?php echo str_limit($post->body,35); ?>

                                        </h3>
                                    </div>
                                </div>
                                <div class="card-footer card-footer-fix">
                                    <small style="float:left"><?php echo e($post->user->name); ?></small>
                                    <button class="btn btn-info float-right btn-sm">Follow</button>
                                </div>
                            </div>
                        </div>




                        

                        




                </div>
            </div>
            

            <div class="col-md-12">

            </div>
        <?php else: ?>
            <p>No posts found</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>













<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>