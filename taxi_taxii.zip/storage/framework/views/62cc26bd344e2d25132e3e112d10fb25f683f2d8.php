<?php $__env->startSection('content'); ?>
<div class="container">
    
    <?php
    $pic=array('500-1.png','500-2.png','500-3.png','500-4.png','500-5.png','500-6.png','500-7.png');
    shuffle($pic);
    ?>

    <?php
    $i=rand(0,count($pic)-1);
    ?>


    <h1><?php echo e($post->title); ?></h1>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-8">
                    <?php echo $post->body; ?>

            </div>
            <div class="col-md-4">
                    
                    <div class="col-md-12">

                        
                        <img style="width:100%;" src="<?php echo e(url('image/'.$pic[$i].' ')); ?>">
                    </div>
                <?php if(!$post->account  ==null): ?>
                    <div class="col-md-12">
                        <p style="text-align:center">
                            ایدی/ایمیل مسافر:
                            <?php if(!Auth::guest()): ?>

                            <span>
                            <?php echo e($post->account); ?>

                            </span>

                            <?php else: ?>
                            <p class="alarm-account">برای مشاهده ابتدا در سایت عضو شوید :/</p>
                            <?php endif; ?>
                        </p>
                    </div>
                <?php endif; ?>
                    
            </div>
        </div>
    </div>
    
    <hr>
    <small><?php echo e($post->created_at); ?></small>
    <small>درخواست توسط <?php echo e($post->user->name); ?></small>
    
    
        
            

            
                
                
            
        
    
    <?php if(!$post->account  ==null): ?>
    <?php if(!Auth::guest()): ?>
        <small>آیدی: <?php echo e($post->account); ?></small>
    <?php endif; ?>
    <?php endif; ?>

    <hr>
    
    <div class="row">
            <div class="col-md-8 offset-md-2" style="padding-top:2%;margin:auto">
                    
            
                    <!-- Tabs with icons on Card -->
                    <div class="card card-nav-tabs">
                        <div class="card-header card-header-primary">
                            <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
                            <div class="nav-tabs-navigation">
                                <div class="nav-tabs-wrapper">
                                    <ul class="nav nav-tabs" data-tabs="tabs">
                                        <li class="nav-item">
                                                <a class="nav-link active" href="#messages" data-toggle="tab">
                                                    
                                                    دیدگاه‌
                                                </a>
                                        </li>
                                        
                                        <li class="nav-item">
                                            <a class="nav-link " href="#profile" data-toggle="tab">
                                                    ارسال دیدگاه
                                                
                                            </a>
                                        </li>
                                        
                                        
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-body ">
                            <div class="tab-content text-center">
                                
                                <div class="tab-pane" id="profile">
                                    <?php if(!Auth::guest()): ?>
                                    <h1>دیدگاه خود را وارد کنید</h1>
                                    <?php echo Form::open(['action' => 'CommentController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                                    
                                        
                                        
                                    
                                    
                                        
                                        
                                    
                                        <div class="form-group">
                                            <input type="hidden" name="comment_body" class="form-control" />
                                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>" />
                                        </div>
                                    <div class="form-group">
                                        <?php echo e(Form::label('body', 'دیدگاه')); ?>

                                        <?php echo e(Form::textarea('body', '', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'دیدگاه'])); ?>

                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" name="comment_body" class="form-control" />
                                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" />
                                    </div>
                                    <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

                                    <?php echo Form::close(); ?>

                                    <?php else: ?>
                                    <div class="col-md-12">
                                        <p>
                                            برای ثبت نظر <a href="/register">عضو شوید</a>
                                        </p>
                                        <p>
                                        </p>
                                    </div>
                                    <?php endif; ?>
            
                                </div>
                                <div class="tab-pane active" id="messages">
                                        
                                        <?php if(count($comments)>0): ?>
                                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="media comment-box">
                                                <div class="media-left">
                                                    <a href="#">
                                                        <img class="img-responsive user-photo" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png">
                                                    </a>
                                                </div>
                                                <div class="media-body">
                                                    
                                                    <h4 class="media-heading"><?php echo e($comment->user->name); ?></h4>
                                                    <h5><?php echo $comment->body; ?></h5>
                                                    
                                                  
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <p>متاسفانه دیدگاهی برای نمایش وجود ندارد
                                            <img src="<?php echo e(url('/image/sad.png')); ?>" alt="surena" style="width: 64px;">
                                        </p>
                                        
                                        <?php endif; ?>
                                        
                                </div>
                                
                            </div>
                        </div></div>
                    <!-- End Tabs with icons on Card -->
            
                </div>
    </div>
    
</div>


   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>