<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>ویرایش درخواست</h1>
    <?php echo Form::open(['action' => ['PostsController@update', $post->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <div class="row">
            <div class="col-md-6 col-12">
                    <div class="form-group">
                        <?php echo e(Form::label('title', 'موضوع')); ?>

                        
                        <?php echo e(Form::text('title',$post->title, ['class' => 'form-control', 'placeholder' => 'هدف'])); ?>

                    </div>
                </div>
                <div class="col-md-6 col-12" style="order:2">
                        <div class="form-group">
                            <?php echo e(Form::label('tag', 'تگ ها')); ?>

                            <?php echo e(Form::text('tag',$post->tag, ['class' => 'form-control','id' =>'form-tags-3', 'placeholder' => '#تاکسی #taxii'])); ?>

                        </div>
                    
                    </div>
    </div>

    <div class="row">
            <div class="col-md-6 col-12">
                <div class="form-group">
                    <div class="col-sm-12">
                        
                            <lable for="category_id" class="control-label">دسته</lable>
                        <select class="form-control" name="category_id" id="school_id">
                            <?php $__currentLoopData = \App\Category::latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" > <?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            
        <div class="col-md-6 col-12" >
            <div class="form-group">
                <?php echo e(Form::label('account', 'آیدی/ایمیل')); ?>

                <?php echo e(Form::text('account',$post->account, ['class' => 'form-control','id' =>'form-tags-3', 'placeholder' => 'آیدی فضای مجازی'])); ?>

            </div>    
        </div>
    
        
    </div>
        <div class="form-group">
            <?php echo e(Form::label('body', 'Body')); ?>

            <?php echo e(Form::textarea('body', $post->body, ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Body Text'])); ?>

        </div>
        <div class="row">
                
            <div class="col-md-6">
                    <?php echo e(Form::hidden('_method','PUT')); ?>

                    <?php echo e(Form::submit('ذخیره', ['class'=>'btn btn-primary'])); ?>

            </div>
        </div>
        
        
        
        
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>