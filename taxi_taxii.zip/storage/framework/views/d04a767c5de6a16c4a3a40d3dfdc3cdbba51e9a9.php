<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>آخرین درخواست‌ها</h1>
     
        
            
            
                
                    
                    
                        
                            
                        
                    
                
            
        
    
    <?php
        $pic=array('500-1.png','500-2.png','500-3.png','500-4.png','500-5.png','500-6.png','500-7.png');
        shuffle($pic);
    ?>






    <?php if(count($posts) > 0): ?>

            
                <div class="container">

                    <div class="row">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-sm-6 col-md-4 col-lg-3 mt-4 mb-4 ">
                            <div class="card  shadow">
                                
                                
                               <?php
                                $i=rand(0,count($pic)-1);
                                ?>

                                    <img style="width:100%;" src="<?php echo e(url('image/'.$pic[$i].' ')); ?>">
                                    




                                <div class="card-block">
                                    <a href="/posts/<?php echo e($post->id); ?>">
                                        <h4 class="card-title" style="text-align:center"><?php echo e($post->title); ?></h4>
                                    </a>
                                    
                                    <div class="meta">
                                        
                                        <?php echo e($post->category->name); ?>



                                    </div>
                                    <div class="card-text">
                                        <h3 style="    margin-bottom: 4rem;                                        ">
                                            <?php echo str_limit($post->body,35); ?>

                                        </h3>
                                    </div>
                                </div>
                                <div class="card-footer card-footer-fix">
                                    <small style="float:left"><?php echo e($post->user->name); ?></small>
                                    <a href="/posts/<?php echo e($post->id); ?>">
                                        <button class="btn btn-info float-right btn-sm">مشاهده</button>
                                    </a>
                                    
                                </div>
                            </div>
                        </div>




                        
                            
                        

                        
                       
                            
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            
            <div class="col-md-12">
                <div class="col-md-3" style=" margin-left: auto; margin-right: auto;">
                    <span> <?php echo e($posts->links( "pagination::bootstrap-4")); ?></span>
                </div>

            </div>
    <?php else: ?>
        <div style="min-height: 50vh">پستی یافت نشد</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>













<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>