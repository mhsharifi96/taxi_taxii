<?php $__env->startSection('content'); ?>



<?php if(session('status')): ?>
  <div class="alert alert-success">
    <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>
<?php if(session('warning')): ?>
  <div class="alert alert-warning">
    <?php echo e(session('warning')); ?>

  </div>
<?php endif; ?>


<div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">ورود</h5>
            <form class="form-signin" role="form" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo e(csrf_field()); ?>

              <div class="form-label-group">
                <input type="email" id="email" name="email" class="form-control" placeholder="Email address" value="<?php echo e(old('email')); ?>" required autofocus>
                
                <label for="inputEmail">ایمیل</label>
              </div>

              <div class="form-label-group">
                <input type="password" id="password" class="form-control" placeholder="Password" name="password"  required>
                
                <label for="password">رمز عبور</label>
                
              </div>

              <div class="custom-control custom-checkbox mb-3">
                <input type="checkbox" class="custom-control-input" id="customCheck1">
                <label class="custom-control-label" for="customCheck1">Remember password</label>
              </div>
              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">ورود</button>
              
              
              <div class="border-top card-body text-center">رمز عبور خود را فراموش کرده اید؟ <a href="<?php echo e(route('password.request')); ?>"> اره </a></div>
              
              <div class="border-top card-body text-center">هنوز ثبت نام نکرده‌اید؟ <a href="/register">ثبت نام</a></div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>