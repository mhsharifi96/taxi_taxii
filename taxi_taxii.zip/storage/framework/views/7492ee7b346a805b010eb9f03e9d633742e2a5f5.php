<?php $__env->startSection('content'); ?>
    
    <div class="header-banner ">
        <div class="container text-center text-location">
            <h1 class="header-title">اولین تاکسی ذهنی در ایران</h1>
            <h4 class="index-text">در مسیر زندگی همیشه یک خط ویژه وجود دارد البته اگر مجوز داشته باشی! <span>مثل یک تاکسی</span></h4>
            
            <?php if(Auth::guest()): ?>
            <p><a class="btn btn-primary btn-lg" href="<?php echo e(url('login')); ?>" role="button">ورود</a> <a class="btn btn-success btn-lg" href="/register" role="button">ثبت نام</a></p>
            
            <?php else: ?>
            <p>
                <a class="btn btn-primary btn-lg" href="/posts/create" role="button">درخواست تاکسی ذهنی</a>
                <a class="btn btn-success btn-lg" href="/posts" role="button">آخرین درخواست ها</a>
             </p>
            
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-12">
        
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>