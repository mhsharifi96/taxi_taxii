<?php $__env->startSection('content'); ?>


<div class="container-fluid">
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
		    <div class="card margin-card">
		        <div class="card-body" style="min-height:55vh;">
		            <div class="row">
		                <div class="col-md-2 border-right">
		                    <h4>پست ها</h4>
		                </div>
		                <div class="col-md-6 mr-auto" style="text-align:left">
                            <a href="posts/create">
                                <button  type="button"  class="btn btn-sm btn-primary ">درخواست جدید</button>
                            </a>

		                </div>
		                
		            </div>
		            <div class="row">
		                <div class="col-md-12">
                            <?php if(count($posts)>0): ?>
		                    <table class="table table-hover ">
                                <thead class="bg-light">
                                  <tr>
                                    
                                    <th class="th-size">موضوع</th>
                                    <th class="col-show th-size">نویسنده</th>
                                    <th class="th-size">دسته</th>
                                    
                                    <th class="col-show th-size">تعداد کامت</th>
                                    <th class="th-size">  تاریخ ایجاد</th>
                                    <th class="th-size">وضعیت</th>
                                    <th class="th-size">ویرایش</th>


                                  </tr>
                                </thead>
                                <tbody>


                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    
                                    <td class="td-conf"><small><?php echo str_limit($post->title,12); ?></small></td>
                                    <td class="col-show td-conf"><small><?php echo e($post->user->name); ?></small></td>
                                    <td class="td-conf"><small><?php echo e($post->category->name); ?></small></td>
                                    
                                    <td class="col-show td-conf"><small>
                                                <?php
                                                     $count=0;
                                                    foreach ($results as $result){

                                                        if($result->post_id == $post->id){
                                                            $count=$count+1;
                                                        }

                                                    }
                                                print($count);
                                                ?>
                                                
                                                
                                                
                                                </small></td>
                                    <td class="td-conf"><small><?php echo e($post->created_at); ?></small></td>
                                     <td class="td-conf"><small>
                                                 <?php
                                                 if($post->available=='1'){
                                                     print ('تایید');
                                                 }
                                                 elseif($post->available=='0'){
                                                     print('تایید نشده');
                                                 }
                                                 else{
                                                     print('در حال بررسی');
                                                 }
                                                 ?>
                                             </small></td>
                                    <td class="td-conf">
                                        <a href="/posts/<?php echo e($post->id); ?>/edit"><i class="fa fa-pencil-square-o"></i></a>
                                        <a href="/posts/<?php echo e($post->id); ?>"><i style="color: #007bff" class="fa fa-eye"></i></a>


                                        
                                        
                                        
                                            
                                            
                                            
                                                
                                                
                                                
                                            
                                        
                                        
                                            
                                            

                                            

                                                
                                            
                                        
                                    </td>
                                  </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                 
                                </tbody>
                              </table>
                              <?php else: ?>
                              <h5>درحال حاضر درخواستی جهت نمایش وجود ندارد.
                              <img src="<?php echo e(url('/image/sad.png')); ?>" alt="" style="width:10%">
                              </h5>
                              <?php endif; ?>


		                </div>
		            </div>
		        </div>
		    </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-3" style=" margin-left: auto; margin-right: auto;">
                <span> <?php echo e($posts->links( "pagination::bootstrap-4")); ?></span>
            </div>

        </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<script>
    $('.post_user').click(function(){
        if( confirm('Are you sure?') )
        {
            var id = $(this).attr('id');
            // Make an ajax call to delete the record and pass the id to identify the record
        }
    });
</script>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>