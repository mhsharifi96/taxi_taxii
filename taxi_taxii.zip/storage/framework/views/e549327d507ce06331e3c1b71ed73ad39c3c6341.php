<?php $__env->startSection('content'); ?>


<div class="container-fluid">
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
		    <div class="card margin-card">
		        <div class="card-body">
		            <div class="row">
		                <div class="col-md-2 border-right">
		                    <h4>پست ها</h4>
		                </div>
		                <div class="col-md-6 mr-auto" style="text-align:left">
                            <a href="posts/create">
                                <button  type="button"  class="btn btn-sm btn-primary ">درخواست جدید</button>
                            </a>

		                </div>
		                
		            </div>
		            <div class="row">
		                <div class="col-md-12">
		                    <table class="table table-hover ">
                                <thead class="bg-light ">
                                  <tr>
                                    
                                    <th>موضوع</th>
                                    <th>نویسنده</th>
                                    <th>دسته بندی</th>
                                    
                                    <th>تعداد کامت</th>
                                    <th>  تاریخ ایجاد</th>
                                    <th>وضعیت</th>
                                    <th>ویرایش</th>


                                  </tr>
                                </thead>
                                <tbody>


                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    
                                    <td><small><?php echo e($post->title); ?></small></td>
                                    <td><small><?php echo e($post->user->name); ?></small></td>
                                    <td><small><?php echo e($post->category->name); ?></small></td>
                                    
                                    <td><small>
                                                <?php
                                                     $count=0;
                                                    foreach ($results as $result){

                                                        if($result->post_id == $post->id){
                                                            $count=$count+1;
                                                        }

                                                    }
                                                print($count);
                                                ?>
                                                
                                                
                                                
                                                </small></td>
                                    <td><small><?php echo e($post->created_at); ?></small></td>
                                     <td><small>
                                                 <?php
                                                 if($post->available=='1'){
                                                     print ('تایید');
                                                 }
                                                 elseif($post->available=='0'){
                                                     print('تایید نشده');
                                                 }
                                                 else{
                                                     print('در حال بررسی');
                                                 }
                                                 ?>
                                             </small></td>
                                    <td>
                                        <a href="/posts/<?php echo e($post->id); ?>/edit"><i class="fa fa-pencil-square-o"></i></a>
                                        <a href="/posts/<?php echo e($post->id); ?>"><button style="background-color: white" type="submit"><i style="color: #007bff" class="fa fa-eye"></i></button></a>
                                        
                                        
                                            
                                            
                                            
                                                
                                                
                                                
                                            
                                        
                                        <form id="delete-form" method="POST" action="posts/<?php echo e($post->id); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>


                                            <a>

                                                <button style="background-color: white" type="submit" value="Delete user"><i  style="color: #007bff" class="fa fa-trash"></i></button>
                                            </a>
                                        </form>
                                    </td>
                                  </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                 
                                </tbody>
                              </table>
		                </div>
		            </div>
		        </div>
		    </div>
        </div>
        <div class="col-md-2"></div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<script>
    $('.post_user').click(function(){
        if( confirm('Are you sure?') )
        {
            var id = $(this).attr('id');
            // Make an ajax call to delete the record and pass the id to identify the record
        }
    });
</script>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>