<?php 

symlink('/home/galenoos/sursiz/storage/app/public/','/home/galenoos/public_html/sursiz.ir/storage/');